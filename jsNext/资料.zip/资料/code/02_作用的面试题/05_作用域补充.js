function foo() {
  m = 100
}

foo()
console.log(m)
