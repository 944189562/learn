const { add, sub, mul } = require('hy_test_utils')

console.log(add(10, 20))
console.log(sub(10, 20))
console.log(mul(10, 20))

