import axios from 'axios'
import Vue from 'vue'


axios.get("url").then(res => {

})

const app = new Vue({})
