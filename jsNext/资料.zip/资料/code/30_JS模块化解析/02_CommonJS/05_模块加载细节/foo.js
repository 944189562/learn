
const name = "why"
const age = 18

console.log("foo:", name)
console.log("foo中的代码被运行")

module.exports = {
  name,
  age
}
