console.log("main")

require("./aaa")
require("./bbb")
