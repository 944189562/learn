console.log("bbb")

require("./ccc")
require("./eee")
