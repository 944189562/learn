const name = "bar"
const age = 100

// es module导出
export {
  name,
  age
}
