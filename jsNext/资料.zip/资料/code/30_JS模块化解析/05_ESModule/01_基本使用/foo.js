export const name = "why"
export const age = 18
