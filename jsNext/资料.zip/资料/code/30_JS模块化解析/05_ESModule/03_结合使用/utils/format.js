function timeFormat() {
  return "2222-12-12"
}

function priceFormat() {
  return "222.22"
}

export {
  timeFormat,
  priceFormat
}
