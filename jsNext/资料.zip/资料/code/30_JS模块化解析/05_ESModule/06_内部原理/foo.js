let name = "why"
let age = 18

setTimeout(() => {
  name = "kobe"
  age = 40
}, 100)

export {
  name,
  age
}
