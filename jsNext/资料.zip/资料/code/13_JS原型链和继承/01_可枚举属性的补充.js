var obj = {
  name: "why",
  age: 18
}

Object.defineProperty(obj, "address", {
  value: "北京市"
})

console.log(obj)
