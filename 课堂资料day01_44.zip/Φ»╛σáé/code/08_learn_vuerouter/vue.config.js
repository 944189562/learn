module.exports = {
  configureWebpack: {
    devServer: {
      // historyApiFallback: true
    }
  }
}
