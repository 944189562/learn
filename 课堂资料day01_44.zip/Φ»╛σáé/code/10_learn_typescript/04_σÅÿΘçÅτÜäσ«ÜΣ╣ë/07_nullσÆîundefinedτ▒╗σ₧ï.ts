let n1: null = null
let n2: undefined = undefined
