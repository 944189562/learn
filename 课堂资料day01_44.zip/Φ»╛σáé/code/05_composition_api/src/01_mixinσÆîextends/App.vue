<template>
  <div>
    <home/>
  </div>
</template>

<script>
  import Home from './pages/Home.vue';

  export default {
    components: {
      Home
    }
  }
</script>

<style scoped>

</style>